﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CandidateManagement.Models
{
    public class Candidate
    {
        public int Id { get; set; }  // Primary Key

        [Required, StringLength(100)]
        public string Name { get; set; }

        [Required, StringLength(50)]
        public string Username { get; set; }

        [Required, StringLength(100)]
        public string Department { get; set; }

        [Display(Name = "Year of Joining")]
        [DataType(DataType.Date)]
        public DateTime YearOfJoining { get; set; }
    }
}
